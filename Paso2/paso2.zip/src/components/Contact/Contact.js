import React from "react";
import "./Contact.css";
import arrow from "../../assets/assets/send.png";

const Contact = () => {
  return (
    <section id="contact">
      <h1 className="contactTitle">Contact Me</h1>
      <span className="contactDescription">
        If you are intrested, please fill out the form below to discuss job
        opportunities.
      </span>
      <form className="contactForm">
        <input
          type="text"
          className="clientName"
          placeholder="Your Name/Organization's Name"
        />
        <input
          type="email"
          className="clientEmail"
          placeholder="name@dominion.com"
        />
        <textarea
          className="clientMessage"
          name="directMessage"
          rows={5}
          placeholder="Message..."
        ></textarea>
        <button className="submit">
          <img src={arrow} alt="" className="arrowImage" /> Submit
        </button>
      </form>
    </section>
  );
};

export default Contact;
