import React from "react";
import "./About.css";
import techImg from "../../assets/assets/technologies.png";
import devImg from "../../assets/assets/development.png";
import skillsImg from "../../assets/assets/otherSkills.png";

export const About = () => {
  return (
    <section id="about">
      <span className="aboutTitle">About me</span>
      <br />
      <span className="aboutDescription">
        I am a young passionate junior software engineer looking foward to work
        on software development and become a full-stack developer one day. My
        strong area of the development is Back-End development, but I can also
        deliver a good performance at the Front-End area. I am able to work on
        diferent Programming Languages such as HTML, CSS, JavaScript, React,
        Java, C/C++, C#, SQL, etc.
      </span>
      <div className="skillList">
        <div className="skill">
          <img src={techImg} alt="Technologies" className="skillImage" />
          <div className="skillText">
            <h2>Technologies</h2>
            <p></p>
          </div>
        </div>
        <div className="skill">
          <img src={devImg} alt="App Development" className="skillImage" />
          <div className="skillText">
            <h2>App Development</h2>
            <p></p>
          </div>
        </div>
        <div className="skill">
          <img src={skillsImg} alt="Other Skills" className="skillImage" />
          <div className="skillText">
            <h2>Other Skills</h2>
            <p></p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
