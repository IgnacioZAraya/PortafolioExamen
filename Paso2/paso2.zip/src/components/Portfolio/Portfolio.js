import React from "react";
import "./Portfolio.css";
import github from "../../assets/assets/github-mark.png";

const Portfolio = () => {
  return (
    <section id="portfolio">
      <h2 className="portfolioTitle">Portfolio</h2>
      <span className="portfolioDescription"></span>
      <div className="portfolioPImages">
        <img src="" alt="" className="portfolioImage" />
        <img src="" alt="" className="portfolioImage" />
        <button className="githubButton">
          <img src={github} alt="" className="githubImage" /> My Repository
        </button>
      </div>
    </section>
  );
};

export default Portfolio;
